package com.example.snake;
import android.content.Context;
import android.graphics.Point;
/*
  The GameObjectFactoryManager class serves as a centralized manager for creating
  various game objects in the Snake game. It provides static methods for creating
  instances of different game objects using their respective factories.
 */
public class GameObjectFactoryManager {
    public static GameObject createApple(Context context, Point spawnRange, int size) {
        GameObjectFactory appleFactory = new AppleFactory();
        return appleFactory.createGameObject(context, spawnRange, size);
    }

    public static GameObject createBadApple(Context context, Point spawnRange, int size) {
        GameObjectFactory badAppleFactory = new BadAppleFactory();
        return badAppleFactory.createGameObject(context, spawnRange, size);
    }

    public static GameObject createBomb(Context context, Point spawnRange, int size) {
        GameObjectFactory bombFactory = new BombFactory();
        return bombFactory.createGameObject(context, spawnRange, size);
    }

    public static GameObject createStar(Context context, Point spawnRange, int size) {
        GameObjectFactory starFactory = new StarFactory();
        return starFactory.createGameObject(context, spawnRange, size);
    }

    public static GameObject createGoodApple(Context context, Point spawnRange, int size) {
        GameObjectFactory goodAppleFactory = new GoodAppleFactory();
        return goodAppleFactory.createGameObject(context, spawnRange, size);
    }
}
