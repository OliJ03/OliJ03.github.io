package com.example.snake;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import java.util.Random;

/*
  The GameObject class represents a generic game object in the Snake game.
  It encapsulates common properties and methods for game objects such as
  location, spawn behavior, and drawing on the canvas.
 */
public class GameObject {
    // The location of the object on the grid
    // Not in pixels
    public Point location = new Point();

    // The range of values we can choose from
    // to spawn an object
    public Point mSpawnRange;
    public int mSize;

    // An image to represent the object
    public Bitmap mBitmap;
    void spawn(){
        // Choose two random values and place the apple
        Random random = new Random();
        location.x = random.nextInt(mSpawnRange.x) + 1;
        location.y = random.nextInt(mSpawnRange.y - 1) + 1;
    }
    Point getLocation(){
        return location;
    }
    void draw(Canvas canvas, Paint paint){
        canvas.drawBitmap(mBitmap,
                location.x * mSize, location.y * mSize, paint);

    }
}
