package com.example.snake;

import android.content.Context;
import android.content.SharedPreferences;

/*
  The HighScoreManager class is responsible for managing the
  high score in the Snake game. It utilizes SharedPreferences to store
  and retrieve the high score.
 */
public class HighScoreManager {
    private static final String PREF_NAME = "HighScorePref";
    private static final String HIGH_SCORE_KEY = "HighScore";

    // Private static instance of the HighScoreManager
    private static HighScoreManager instance;

    // Private constructor to prevent direct instantiation
    private HighScoreManager() {
    }

    // Public method to get the singleton instance of HighScoreManager
    public static synchronized HighScoreManager getInstance() {
        if (instance == null) {
            instance = new HighScoreManager();
        }
        return instance;
    }

    // Public method to get the high score from SharedPreferences
    public int getHighScore(Context context) {
        SharedPreferences preferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        return preferences.getInt(HIGH_SCORE_KEY, 0);
    }

    // Public method to set the high score in SharedPreferences
    public void setHighScore(Context context, int score) {
        SharedPreferences preferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putInt(HIGH_SCORE_KEY, score);
        editor.apply();
    }
}