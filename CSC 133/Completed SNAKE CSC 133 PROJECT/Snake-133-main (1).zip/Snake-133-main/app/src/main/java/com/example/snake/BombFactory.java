package com.example.snake;

import android.content.Context;
import android.graphics.Point;
/*
  The BombFactory class implements the GameObjectFactory interface
  and is responsible for creating instances of the Bomb class.
  It facilitates the creation and initialization of Bomb objects
  within the Snake game.
 */
public class BombFactory implements GameObjectFactory {
    @Override
    public GameObject createGameObject(Context context, Point spawnRange, int size) {
        Bomb bomb = new Bomb(context, spawnRange, size);
        bomb.spawn();
        return bomb;
    }
}

