package com.example.snake;

/*
  SnakeMovement class represents the movement speed control for the snake.
  It provides methods to set, increase, decrease, and retrieve the speed value.
 */
class SnakeMovement {
    //the speed of the snake
    private static double speedVal = 10;

    // Method to set the speed
    public void setSpeedVal(double speed) {
        this.speedVal = speed;
    }

    // Method to increase the speed
    public static double upSpeedVal() {
        if (speedVal <= 20) {
            speedVal = speedVal + 0.5;
        }
        return speedVal;
    }

    // Method to reduce the speed
    public static double lowerSpeedVal() {
        if (speedVal > 1) {
            speedVal = speedVal - 0.2;
        }
        return speedVal;
    }

    // Method to get the speed value
    public static double getSpeedVal() {
        return speedVal;
    }

}

