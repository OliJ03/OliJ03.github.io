package com.example.snake;

import android.content.Context;
import android.graphics.Point;
/*
  The BadAppleFactory class implements the GameObjectFactory interface
  and is responsible for creating instances of the Apple class.
  It facilitates the creation and initialization of Apple objects
  within the Snake game.
 */
public class BadAppleFactory implements GameObjectFactory {
    @Override
    public GameObject createGameObject(Context context, Point spawnRange, int size) {
        BadApple badApple = new BadApple(context, spawnRange, size);
        badApple.spawn();
        return badApple;
    }
}