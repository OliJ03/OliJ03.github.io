package com.example.snake;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
/*
  The bomb class represents the bomb object in the Snake game.
  It extends the GameObject class and is responsible for handling
  the bomb's appearance and location.*/
public class Bomb extends GameObject {
    private Bitmap mBitmapBomb;

    public Bomb(Context context, Point sr, int s) {
        mSpawnRange = sr;
        // Make a note of the size of an star
        mSize = s;
        // Hide the star off-screen until the game starts
        location = new Point();
        location.x = -15;

        // Load Bomb image from resources
        mBitmapBomb = BitmapFactory.decodeResource(context.getResources(), R.drawable.bomb_image);

        //resize the Bomb
        mBitmapBomb = Bitmap.createScaledBitmap(mBitmapBomb, s, s, false);
    }

    @Override
    public Point getLocation() {
        return location;
    }

    public void spawn() {
        super.spawn();
    }

    public void draw(Canvas canvas, Paint paint) {
        // Draw the star on the canvas
        canvas.drawBitmap(mBitmapBomb,
                location.x * mSize, location.y * mSize, paint);
    }
}

