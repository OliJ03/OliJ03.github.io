package com.example.snake;

import android.content.Context;
import android.graphics.Point;
/*
  The StarFactory class implements the GameObjectFactory interface
  and is responsible for creating instances of the Star class.
  It facilitates the creation and initialization of Star objects
  within the Snake game.
 */
public class StarFactory implements GameObjectFactory {
    @Override
    public GameObject createGameObject(Context context, Point spawnRange, int size) {
        Star star = new Star(context, spawnRange, size);
        star.spawn(); // Optionally, you can call spawn here or in the constructor
        return star;
    }
}
