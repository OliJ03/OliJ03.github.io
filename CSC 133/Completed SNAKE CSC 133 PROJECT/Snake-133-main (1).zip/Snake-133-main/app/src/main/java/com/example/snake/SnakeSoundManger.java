package com.example.snake;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.content.res.AssetManager;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Build;

import java.io.IOException;

/*
  SnakeSoundManger class manages the sound effects and background music for the snake game.
  It uses SoundPool to handle short sound effects and provides methods for playing, pausing,
  resuming, stopping, and releasing sounds.
 */
public class SnakeSoundManger {
    private SoundPool mSP;
    private int mEat_ID = -1;
    private int mCrash_ID = -1;
    private int mBackgroundID = -1;

    int StreamId;
    private SoundStrategy eatSoundStrategy;
    private SoundStrategy deathSoundStrategy;

    public SnakeSoundManger(Context context) {
        soundBuilder(context);
        bootUpSounds(context);
        eatSoundStrategy = new EatSoundStrategy(mSP, mEat_ID);
        deathSoundStrategy = new DeathSoundStrategy(mSP, mCrash_ID);
    }

    protected void bootUpSounds(Context context) {
        try {
            AssetManager assetManager = context.getAssets();
            AssetFileDescriptor descriptor;

            // Prepare the sounds in memory
            descriptor = assetManager.openFd("get_apple.ogg");
            mEat_ID = mSP.load(descriptor, 0);

            descriptor = assetManager.openFd("snake_death.ogg");
            mCrash_ID = mSP.load(descriptor, 0);

            descriptor = assetManager.openFd("backgroundmusic.mp3");
            mBackgroundID = mSP.load(descriptor, 0);

        } catch (IOException e) {
            // Error
        }
    }

    private void soundBuilder(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            AudioAttributes audioAttributes = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build();

            mSP = new SoundPool.Builder()
                    .setMaxStreams(5)
                    .setAudioAttributes(audioAttributes)
                    .build();
        } else {
            mSP = new SoundPool(5, AudioManager.STREAM_MUSIC, 0);
        }
    }

    public void playAppleSound() {
        eatSoundStrategy.playSound();
    }
    public void playDeathSound() {
        deathSoundStrategy.playSound();
    }
    public void playBackgroundMusic() {
        StreamId = mSP.play(mBackgroundID, 1, 1, 0, 99999, 1);
    }
    public void pause() {
        mSP.pause(StreamId);
    }
    public void resume() {
        mSP.resume(StreamId);
    }
    public void release() {
        mSP.release();
    }

    public void stop() {
        mSP.stop(StreamId);
    }
}