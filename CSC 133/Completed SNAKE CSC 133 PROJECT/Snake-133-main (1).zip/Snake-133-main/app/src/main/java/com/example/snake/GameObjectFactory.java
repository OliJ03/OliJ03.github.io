package com.example.snake;

import android.content.Context;
import android.graphics.Point;

/*
  The GameObjectFactory interface defines a contract for creating game objects
  in the Snake game. Classes implementing this interface are responsible for
  creating and initializing instances of the GameObject class or its subclasses.
 */
public interface GameObjectFactory {
    GameObject createGameObject(Context context, Point spawnRange, int size);
}
