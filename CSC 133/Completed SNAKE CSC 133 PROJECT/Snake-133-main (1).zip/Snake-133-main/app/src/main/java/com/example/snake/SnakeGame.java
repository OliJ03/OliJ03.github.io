package com.example.snake;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.widget.Button;
import android.os.Handler;
import android.os.Looper;
import android.widget.RelativeLayout;
import android.app.Activity;
import android.widget.RelativeLayout.LayoutParams;

/*
  SnakeGame class represents the game engine for the Snake game.
  It manages the game loop, drawing, player input, and game state.
 */
class SnakeGame extends SurfaceView implements Runnable{

    // Objects for the game loop/thread
    private Thread mThread = null;
    // Control pausing between updates
    private long mNextFrameTime;
    // Is the game currently playing and or paused?
    private volatile boolean mPlaying = false;
    private volatile boolean mPaused = true;
    private boolean firstRun = true;
    private boolean gameOver = false;

    // for playing sound effects
    private SnakeSoundManger mSnakeSound;

    // The size in segments of the playable area
    private final int NUM_BLOCKS_WIDE = 40;
    private int mNumBlocksHigh;

    // How many points does the player have
    public int mScore;

    // Objects for drawing
    private Canvas mCanvas;
    private SurfaceHolder mSurfaceHolder;
    private Paint mPaint;

    // Game Objects
    private Snake mSnake;
    private Apple mApple;
    private BadApple mBadApple;
    private GoodApple mGoodApple;
    private Star mStar;
    private Bomb mBomb;

    //play/pause requirements
    private Button btnPlayPause;
    private Button btnStop;
    private Handler uiHandler;

    // HighScoreManager instance
    private HighScoreManager highScoreManager;

   // Object for managing game object factories
    private GameObjectFactoryManager factoryManager;

    // Constructor for SnakeGame
    public SnakeGame(Context context, Point size) {
        super(context);

        // Work out how many pixels each block is
        int blockSize = size.x / NUM_BLOCKS_WIDE;
        // How many blocks of the same size will fit into the height
        mNumBlocksHigh = size.y / blockSize;

        // Initialize the SoundPool
        mSnakeSound = new SnakeSoundManger(context);

        // Initialize the drawing objects
        mSurfaceHolder = getHolder();
        mPaint = new Paint();

        factoryManager = new GameObjectFactoryManager();

        // Call the constructors of our in game objects
        mApple = (Apple) factoryManager.createApple(context, new Point(NUM_BLOCKS_WIDE, mNumBlocksHigh), blockSize);
        mGoodApple = (GoodApple) factoryManager.createGoodApple(context, new Point(NUM_BLOCKS_WIDE, mNumBlocksHigh), blockSize);
        mBadApple = (BadApple) factoryManager.createBadApple(context, new Point(NUM_BLOCKS_WIDE, mNumBlocksHigh), blockSize);
        mStar = (Star) factoryManager.createStar(context, new Point(NUM_BLOCKS_WIDE, mNumBlocksHigh), blockSize);
        mBomb = (Bomb) factoryManager.createBomb(context, new Point(NUM_BLOCKS_WIDE, mNumBlocksHigh), blockSize);

        //Make our snake
        mSnake = new Snake(context,
                new Point(NUM_BLOCKS_WIDE,
                        mNumBlocksHigh),
                blockSize);
        // Initialize the buttons
        btnPlayPause = new Button(context);
        btnPlayPause.setText("_______  Resume");
        btnPlayPause.setOnClickListener(v -> onPlayClicked());

        btnStop = new Button(context);
        btnStop.setText("Pause");
        btnStop.setOnClickListener(v -> onPauseClicked());

        // Initialize the UI Handler to update UI components from a background thread
        uiHandler = new Handler(Looper.getMainLooper());
        // Add the buttons to the layout
        addButtonsToLayout();
        highScoreManager = HighScoreManager.getInstance();
    }

    // Called to start a new game
    public void newGame() {
        mSnakeSound.stop();
        // reset the snake
        mSnake.reset(NUM_BLOCKS_WIDE, mNumBlocksHigh);

        // Get the apple ready for dinner
        mApple.spawn();
        mGoodApple.spawn();
        mBadApple.spawn();
        mStar.spawn();
        mBomb.spawn();

        // Reset the mScore
        mScore = 0;

        // Setup mNextFrameTime so an update can triggered
        mNextFrameTime = System.currentTimeMillis();

        mSnakeSound.playBackgroundMusic();
    }

    // Handles the game loop
    @Override
    public void run() {

        while (mPlaying) {
            if(!mPaused) {
                // Update 10 times a second
                if (updateRequired()) {
                    update();
                }
            }
            draw();
        }
    }


    // Check to see if it is time for an update
    public boolean updateRequired() {

        // Run at 10 frames per second
        final long TARGET_FPS = (long)SnakeMovement.getSpeedVal();
        // There are 1000 milliseconds in a second
        final long MILLIS_PER_SECOND = 1000;

        // Are we due to update the frame
        if(mNextFrameTime <= System.currentTimeMillis()){
            // Tenth of a second has passed

            // Setup when the next update will be triggered
            mNextFrameTime =System.currentTimeMillis()
                    + MILLIS_PER_SECOND / TARGET_FPS;

            // Return true so that the update and draw
            // methods are executed
            return true;
        }
        return false;
    }


    // Update all the game objects
    public void update() {

        // Move the snake
        mSnake.move();

        // Did the head of the snake eat the apple?
        if (mSnake.checkDinner(mApple.getLocation(), false)) {
            mApple.spawn();
            mScore++;
            // Check and update high score
            //HighScoreManager highScoreManager = HighScoreManager.getInstance();
            int highScore = highScoreManager.getHighScore(getContext());

            // Check if the current score is greater than the stored high score
            if (mScore > highScore) {
                // Update the high score using the singleton instance
                highScoreManager.setHighScore(getContext(), (int) mScore);
            }
            // Play a sound
            mSnakeSound.playAppleSound();
        }
        if (mSnake.checkDinner(mGoodApple.getLocation(), false)) {
            mGoodApple.spawn();
            //slows down the snake's speed
            SnakeMovement.lowerSpeedVal();
            mScore = mScore + (1 + (int)(Math.random() * ((2 - 1) + 1)));

            // Check and update high score
            //HighScoreManager highScoreManager = HighScoreManager.getInstance();
            int highScore = highScoreManager.getHighScore(getContext());
            if (mScore > highScore) {
                // Update the high score using the singleton instance
                highScoreManager.setHighScore(getContext(), (int) mScore);
            }
            // Play a sound
            mSnakeSound.playAppleSound();
        }
        if(mSnake.checkDinner(mBadApple.getLocation(), true)){
            // This reminds me of Edge of Tomorrow.
            // One day the apple will be ready!
            mBadApple.spawn();
            //speeds up the snake's speed
            SnakeMovement.upSpeedVal();
            if (mSnake.isInvincible()) {

            }else{
                mScore = mScore - (1 + (int)(Math.random() * ((2 - 1) + 1)));
            }
            // Add to  mScore

            // Play a sound
            mSnakeSound.playDeathSound();
        }
        if (mSnake.checkDinner(mStar.getLocation(), true)) {
            // Consume the star and check for invincibility
            mStar.spawn();

            if (!mSnake.isInvincible()) {
                // Provide invincibility logic here only if the snake is not already invincible
                mSnake.setInvincible(true);
                // Schedule the end of invincibility after a certain duration (e.g., 10 seconds)
                uiHandler.postDelayed(() -> mSnake.setInvincible(false), 10000); // 10 seconds in milliseconds
                // Play a sound
                //mSnakeSound.playStarSound();
                mSnakeSound.playAppleSound();
            }
        }
        if(mSnake.checkDinner(mBomb.getLocation(), true)){
            mBomb.spawn();
            if (mSnake.isInvincible()) {
                mSnakeSound.playAppleSound();
            }else{
                mSnakeSound.playDeathSound();
                mPaused =true;
                gameOver =true;
            }
        }


        if(mScore < 0) {
            mPaused = true;
            gameOver = true;
            mSnakeSound.playDeathSound();
            newGame();
        }

        // Did the snake die?
        if (mSnake.detectDeath()) {
            // Pause the game ready to start again
            mSnakeSound.playDeathSound();
            mPaused =true;
            gameOver =true;

            if (firstRun) {
                firstRun = false;
            }
        }


    }

    // Do all the drawing
    public void draw() {
        // Get a lock on the canvas
        if (mSurfaceHolder.getSurface().isValid()) {
            mCanvas = mSurfaceHolder.lockCanvas();
            // Fill the screen with a color
            mCanvas.drawColor(Color.argb(255, 26, 128, 182));

            // Set the size and color of the paint for the text
            mPaint.setColor(Color.argb(255, 255, 255, 255));
            mPaint.setTextSize(120);

            // Draw the current score
            String scoreText = "Score: " + mScore;
            float scoreTextWidth = mPaint.measureText(scoreText);
            mCanvas.drawText(scoreText, mCanvas.getWidth()- scoreTextWidth - 20, 240, mPaint);

            // Draw the high score
            String highScoreText = "High Score: " + highScoreManager.getHighScore(getContext());
            float highScoreTextWidth = mPaint.measureText(highScoreText);
            mCanvas.drawText(highScoreText, mCanvas.getWidth() - highScoreTextWidth-20, 120, mPaint);

            // Draw the invincibility status
            if (mSnake.isInvincible()) {
                //mPaint.setTextSize(80);
                mCanvas.drawText("Invincible", 20, 240, mPaint);
            }
            // Draw the apple and the snake
            mApple.draw(mCanvas, mPaint);
            mSnake.draw(mCanvas, mPaint);
            mBadApple.draw(mCanvas, mPaint);
            mGoodApple.draw(mCanvas, mPaint);
            mStar.draw(mCanvas, mPaint);
            mBomb.draw(mCanvas, mPaint);

            // when game is over
            if(gameOver) {
                drawGameOver();
            } else if (firstRun && mPaused) {
                // Draw "Tap to play" only on the first run
                mPaint.setTextSize(250);
                mCanvas.drawText("Welcome to Snake", 100, 500, mPaint);
                mPaint.setTextSize(120);
                mCanvas.drawText("Tap to play", 200, 700, mPaint);
            }
            if(!mPlaying){
                drawPaused();
            }

            // Unlock the canvas and reveal the graphics for this frame
            mSurfaceHolder.unlockCanvasAndPost(mCanvas);
        }
    }
    private void drawGameOver() {
        mPaint.setTextSize(250);
        mCanvas.drawText("Game Over", 200, 500, mPaint);
        mPaint.setTextSize(120);
        mCanvas.drawText("Tap to play again", 200, 700, mPaint);
        mCanvas.drawText("Return to Home", 200, 900, mPaint);
        mSnakeSound.stop();
    }


    private void drawPaused() {
        mPaint.setTextSize(250);
        mCanvas.drawText("Paused", 200, 500, mPaint);
        mPaint.setTextSize(120);
        mCanvas.drawText("Tap Resume to Play", 200, 700, mPaint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent motionEvent) {
        switch (motionEvent.getAction() & MotionEvent.ACTION_MASK) {
            case MotionEvent.ACTION_UP:
                if (mPaused || gameOver) {
                    float x = motionEvent.getX();
                    float y = motionEvent.getY();

                    // Check if "Tap to play again" is clicked
                    if (x > 200 && x < 1000 && y > 600 && y < 720) {
                        mPaused = false;
                        newGame();
                        gameOver = false;
                        return true;
                    }

                    // Check if "Return to Home" is clicked
                    if (x > 200 && x < 1000 && y > 800 && y < 920) {
                        // Handle the logic to return to the home screen
                        returnToHome();
                        return true;
                    }
                }

                // Let the Snake class handle the input
                mSnake.switchHeading(motionEvent);
                break;

            default:
                break;
        }
        return true;
    }


    private void returnToHome() {
        // Handle the logic to return to the home screen
        // For example, you might launch a new activity or finish the current one.
        // Replace the following line with your specific logic.
        Intent homeIntent = new Intent(getContext(), MainActivity.class);
        getContext().startActivity(homeIntent);
        ((Activity) getContext()).finish();
    }


    // Method to add buttons to the layout dynamically
    private void addButtonsToLayout() {
        LayoutParams layoutParamsPlayPause = new LayoutParams(
                LayoutParams.WRAP_CONTENT,
                LayoutParams.WRAP_CONTENT
        );
        layoutParamsPlayPause.addRule(RelativeLayout.BELOW, this.getId());
        layoutParamsPlayPause.setMargins(16, 16, 16, 16);
        btnPlayPause.setLayoutParams(layoutParamsPlayPause);
        btnPlayPause.setOnClickListener(v -> onPlayClicked());

        LayoutParams layoutParamsStop = new LayoutParams(
                LayoutParams.WRAP_CONTENT,
                LayoutParams.WRAP_CONTENT
        );
        layoutParamsStop.addRule(RelativeLayout.RIGHT_OF, btnPlayPause.getId());
        layoutParamsStop.addRule(RelativeLayout.BELOW, this.getId());
        layoutParamsStop.setMargins(16, 16, 16, 16);
        btnStop.setLayoutParams(layoutParamsStop);
        btnStop.setOnClickListener(v -> onPauseClicked());

        uiHandler.post(() -> {
            ((Activity) getContext()).addContentView(btnPlayPause, layoutParamsPlayPause);
            ((Activity) getContext()).addContentView(btnStop, layoutParamsStop);
        });
    }

    // on click for buttons
    private void onPlayClicked() {
        android.util.Log.d("play/pause", "Play/Pause button clicked");
        resume();
    }

    private void onPauseClicked() {
        pause();
    }
    // Stop the thread
    public void pause() {
        mPlaying = false;
        try {
            mThread.join();
        } catch (InterruptedException e) {
            // Error
        }
        mSnakeSound.pause();
    }

    // Start the thread
    public void resume() {
        android.util.Log.d("resume", "Resuming game");
        mPlaying = true;
        mThread = new Thread(this);
        mThread.start();
        mSnakeSound.resume();
    }
}