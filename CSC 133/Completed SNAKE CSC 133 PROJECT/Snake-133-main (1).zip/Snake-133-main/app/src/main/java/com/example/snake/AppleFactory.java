package com.example.snake;

import android.content.Context;
import android.graphics.Point;
/*
  The AppleFactory class implements the GameObjectFactory interface
  and is responsible for creating instances of the Apple class.
  It facilitates the creation and initialization of Apple objects
  within the Snake game.
 */
public class AppleFactory implements GameObjectFactory {
    @Override
    public GameObject createGameObject(Context context, Point spawnRange, int size) {
        Apple apple = new Apple(context, spawnRange, size);
        apple.spawn(); // Optionally, you can call spawn here or in the constructor
        return apple;
    }
}
