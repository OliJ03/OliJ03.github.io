package com.example.snake;

/*
  SoundStrategy interface defines a contract for classes that implement specific sound strategies.
  Classes implementing this interface should provide a method to play a sound.
 */

// Play the sound based on the implemented strategy
public interface SoundStrategy {
    void playSound();
}
