package com.example.snake;
import android.media.SoundPool;
/*
  The EatSoundStrategy class implements the SoundStrategy interface
  and is responsible for playing a sound when the snake eats an apple, good apple or a star .
 */
public class EatSoundStrategy implements SoundStrategy{
    // The SoundPool instance for playing sounds
    private SoundPool mSP;
    private int mEatID;
    // The sound resource ID for the sound
    public EatSoundStrategy(SoundPool soundPool, int eatID) {
        this.mSP = soundPool;
        this.mEatID = eatID;
    }
    // Plays the Sound
    @Override
    public void playSound() {
        mSP.play(mEatID, 1, 1 ,0,0,1);

    }
}
