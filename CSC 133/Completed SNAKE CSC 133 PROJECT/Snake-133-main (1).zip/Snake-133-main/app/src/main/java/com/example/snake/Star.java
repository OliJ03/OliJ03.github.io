package com.example.snake;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
/*
  The Star class represents the Star object in the Snake game.
  It extends the GameObject class and is responsible for handling
  the Star's appearance and location.
 */
public class Star extends GameObject{
    private Bitmap mBitmapStar;

    public Star(Context context, Point sr, int s) {
        mSpawnRange = sr;
        // Make a note of the size of an star
        mSize = s;
        // Hide the star off-screen until the game starts
        location = new Point();
        location.x = -15;

        // Load star image from resources
        mBitmapStar = BitmapFactory.decodeResource(context.getResources(), R.drawable.star_image);

        //resize the star
        mBitmapStar = Bitmap.createScaledBitmap(mBitmapStar, s, s, false);
    }
    @Override
    public Point getLocation() {
        return location;
    }

    public void spawn() {
       super.spawn();
    }

    public void draw(Canvas canvas, Paint paint) {
        // Draw the star on the canvas
        canvas.drawBitmap(mBitmapStar,
                location.x * mSize, location.y * mSize, paint);
    }
}

