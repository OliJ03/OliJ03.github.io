package com.example.snake;

import android.media.SoundPool;

/*
  The DeathSoundStrategy class implements the SoundStrategy interface
  and is responsible for playing a sound when the snake dies or eats bad apple.
 */
public class DeathSoundStrategy implements SoundStrategy{
    // The SoundPool instance for playing sounds
    private SoundPool mSP;
    // The sound resource ID for the sound
    private int mCrashID;
    public DeathSoundStrategy(SoundPool soundPool, int crashID) {
        this.mSP = soundPool;
        this.mCrashID = crashID;
    }
    // Plays the sound
    @Override
    public void playSound() {
        mSP.play(mCrashID, 1, 1 ,0,0,1);
    }
}
