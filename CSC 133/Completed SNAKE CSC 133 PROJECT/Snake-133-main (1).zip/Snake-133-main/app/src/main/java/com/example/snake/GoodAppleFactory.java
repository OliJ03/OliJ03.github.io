package com.example.snake;

import android.content.Context;
import android.graphics.Point;
/*
  The GoodAppleFactory class implements the GameObjectFactory interface
  and is responsible for creating instances of the GoodApple class.
  It facilitates the creation and initialization of GoodApple objects
  within the Snake game.
 */
public class GoodAppleFactory implements GameObjectFactory {
    @Override
    public GameObject createGameObject(Context context, Point spawnRange, int size) {
        GoodApple goodApple = new GoodApple(context, spawnRange, size);
        goodApple.spawn();
        return goodApple;
    }
}